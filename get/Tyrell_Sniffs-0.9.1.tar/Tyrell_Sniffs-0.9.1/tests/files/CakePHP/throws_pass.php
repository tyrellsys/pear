<?php

namespace CakePHP;

use Other\Crap;
use Other\Error as OtherError;

class Throws {

/**
 * Test throws
 *
 * @throws Exception hoge
 * @throws CakePHP\Boom ああああ
 * @throws CakePHP\Error\Boom ああああ
 * @throws Other\Crap ああああ
 * @throws Other\Error\Issue ああああ
 * @return void
 */
    public function test() {
        switch ($a) {
            case 1:
                throw new Boom();
            case 2:
                throw new Error\Boom();
            case 3:
                throw new OtherError\Issue();
            case 4:
                throw new Crap();
            default:
                throw new \Exception();
        }
    }
}
