<?php

/**
 * CryptObject Class
 */
class CryptObject extends AppModel {

/**
 * DBテーブルは使わない
 */
    public $useTable = false;

/**
 *  mcrypt_module_openの戻り値保持用のプロパティ
 */
    protected $_td;

/**
 * php-mcrypt関数の初期化
 *
 * @param string $key 暗号シード nullの場合、Configure::read('Security.salt')を利用します。
 *
 * @return boolean
 */
    protected function _init($key = null) {
        if (is_null($key)) {
            $key = Configure::read('Security.salt');
        }
        if (($this->_td = mcrypt_module_open(MCRYPT_BLOWFISH, '', 'ecb', '')) === false) {
            return false;
        }
        if (($iv = mcrypt_create_iv(8, MCRYPT_RAND)) === false) {
            return false;
        }
        $result = mcrypt_generic_init($this->_td, $key, $iv);
        if ($result === false || $result <= -1) {
            return false;
        }
        return true;
    }

/**
 * 暗号化
 *
 * @param string $str 文字列
 * @param string $key 暗号シード
 *
 * @return string 暗号化後の値（バイナリ）
 */
    protected function _encode($str) {
        return mcrypt_generic($this->_td, $str);
    }

/**
 * 復号化
 *
 * @param string $str 文字列（バイナリ）
 * @param string $key 暗号シード
 *
 * @return string 復号化後の値
 */
    protected function _decode($str) {
        return mdecrypt_generic($this->_td, $str);
    }

/**
 * php-mcryptにより暗号化し、バイナリをbin2hex()で変換した値を返却します。
 *
 * @param string $str 文字列
 * @param string $key 暗号シード
 *
 * @return string 暗号化後の値をbin2hex()で変換した値
 */
    public function encode($str, $key = null) {
        if (!$this->_init($key)) {
            return false;
        }

        return bin2hex($this->_encode($str));
    }

/**
 * bin2hexで変換された値をphp-mcryptで復号化した値を返却します。
 *
 * @param string $str bin2hexに変換された文字列
 * @param string $key 暗号シード
 *
 * @return string 復号化した文字列
 */
    public function decode($str, $key = null) {
        if (!$this->_init($key)) {
            return false;
        }

        return rtrim($this->_decode(pack('H*', $str)), "\0");
    }
}
