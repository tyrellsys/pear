<?php

use Last;
use More;

class Foo {

	use BarTrait;
	use FirstTrait;

}