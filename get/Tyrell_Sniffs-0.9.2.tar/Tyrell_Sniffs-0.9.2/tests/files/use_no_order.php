<?php

use Good;
use Bad;

class Foo {
}
