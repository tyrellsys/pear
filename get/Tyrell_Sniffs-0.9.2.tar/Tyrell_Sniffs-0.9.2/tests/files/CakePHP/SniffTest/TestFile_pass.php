<?php
namespace CakePHP\SniffTest;
class TestFile
{
}
