<?php

namespace CakePHP;
class BadNs {
}
