<?php
namespace CakePHP\SniffTest {
    class TestFile {
/**
 * hogehoge
 *
 * @return void
 */

        public function hoge() {
            /*  */
        }

    }
}
