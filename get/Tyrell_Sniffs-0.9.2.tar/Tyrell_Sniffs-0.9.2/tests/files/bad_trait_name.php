<?php

trait Foo {
}
