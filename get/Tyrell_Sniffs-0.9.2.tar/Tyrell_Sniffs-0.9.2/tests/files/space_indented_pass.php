<?php
$array = array(1, 2, 3);
foreach ($array as $i) {
    echo $i;
}
