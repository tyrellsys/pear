<?Php
/**
 * LdapGroup
 *
 * LDAPのグループ制御
 *
 */
class LdapGroup extends AppModel {

    /*
     * モデル名
     */
    public $name = 'LdapGroup';

    /*
     * DBソース
     */
    public $useDbConfig = 'ldap';

    /*
     * プライマリキー:ou
     */
    public $primaryKey = 'ou';

    /*
     * 使用するDBテーブル・LDAP DataSourceの場合はここに属性をセットします
     */
    public $useTable = false; // Adapt this parameter to your data

/**
 * 与えられたデータでLDAPのグループ情報を更新します。
 *
 * @param array $data デバイスグループ名
 *
 * @return boolean success
 */
    public function update(array $data) {
        $group = Hash::get($data,'Device.group');
        if (empty($group)) {
            return false;
        }
        $conditions = array(
                            'ou' => $group,
                           );
        $this->useTable = 'ou=certificates,dc=panasonic';
        $data = $this->find('all',array(
                                        'conditions' => $conditions,
                                        )
                            );
        if (!$data) {
            // create an new group
            $data = array(
                          'LdapGroup'
                          => array(
                                  'objectclass' => 'organizationalUnit',
                                  'ou' => $group,
                                  )
                          );
            $this->useTable = "ou=certificates,dc=panasonic";
            $this->save($data);
        }
    }
}