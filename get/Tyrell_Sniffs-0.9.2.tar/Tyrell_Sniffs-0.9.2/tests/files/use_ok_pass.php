<?php

use Good;
use Ok;
use Test;

/**
 * Device
 *
 * 証明書のためのコントローラ
 *
 * @category Controller
 * @package  WACS
 * @author   Kazuhiko Hotta <k-hotta@tyrellsys.com>
 * @license  Commerical Licence.
 * @link     None
 */
class Foo {
}
