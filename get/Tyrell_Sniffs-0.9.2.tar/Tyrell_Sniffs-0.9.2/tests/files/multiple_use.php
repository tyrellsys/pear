<?php
use CakePHP\Test,
	CakePHP\Fail;

class Foo {
}
